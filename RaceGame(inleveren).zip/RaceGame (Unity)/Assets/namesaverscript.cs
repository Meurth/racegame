﻿using UnityEngine;
using System.Collections;

public class namesaverscript : MonoBehaviour
{
    public string player1name;
    public string player2name;




    void Update()
    {


    }
}
